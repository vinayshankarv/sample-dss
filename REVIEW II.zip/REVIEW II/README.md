# ScrapeWise DSS — Review II Readiness Addendum


## Live Walkthrough of Early Prototype
- **Single command** to launch: `streamlit run pricing_intelligence_system.py`
- Toggle **Use live scraping** to fetch real Amazon.in / Flipkart results in INR.
- Built‑in **What‑If Simulator** (sidebar) to stress‑test competitor price shocks.

## Architecture Diagram
- Open `scrapewise_dss.py` to render a Streamlit Graphviz architecture view (UI • Model base • Data layer).
- Data layer now includes optional **SQLite** persistence toggled in `config.py`.

## Key Algorithms / Models
- **Scraper**: UA & proxy rotation, retries with exponential backoff, pagination, INR normalization, standard schema.
- **Analytics**: Price difference, margin %, risk level, opportunity score.
- **What‑If**: Deterministic transformation of competitor prices to recompute KPIs live.
- (**Optional**) ML model (RandomForest) can be re‑enabled from earlier version; the pipeline is unchanged and can learn from the **historical scraped dataset** stored under `data/`.

## Example Scenario
1. Set query = *"laptop"*, platforms = *Amazon + Flipkart*, pages = 2.
2. Observe baseline price gaps and risk.
3. Move the *What‑If* slider to **+15%** competitor price.
4. Note increases in **Opportunity Score** and changes in **Risk Level** for items with sufficient stock.

## Outputs from Scraper
Standard columns are defined in `config.py` → `STANDARD_COLUMNS`:

```
Scrape_Timestamp | Query | Platform | Product | Product_URL | Image_URL
Competitor_Price | Currency | Rating | Reviews | Availability | Seller | Additional
```

Persisted as CSV/JSON (and optional SQLite) in `data/`.

## Training Datasets (for ML)
Aggregate daily scrapes (same schema as above) and join with internal data:

```
Product | Our_Price | Cost_Price | Stock | Category | <scraped columns>
```

Target options:
- **Price recommendation** (regression on `Our_Price` given features)
- **Win/lose uplift** (classification from historical sales, if available)

## 🇮🇳 INR‑Native
- Amazon.in + Flipkart selectors.
- Currency normalized to **INR** with pretty formatting in UI.
- Optional FX converter hook in `config.py` if scraping USD sites.

---

### Run
```bash
pip install -r requirements.txt
streamlit run pricing_intelligence_system.py
```

### Notes
- For headless servers, ensure Chrome + chromedriver match.
- To enable SQLite, set `SAVE_SQLITE = True` in `config.py`.
