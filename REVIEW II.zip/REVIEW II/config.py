"""
ScrapeWise DSS — E‑commerce Scraper Configuration
Production‑ready knobs for scraping India‑focused marketplaces.
"""

from pathlib import Path

# ---------- Project Paths ----------
BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
LOG_DIR = BASE_DIR / "logs"
for d in (DATA_DIR, LOG_DIR):
    d.mkdir(parents=True, exist_ok=True)

# ---------- Browser / Selenium ----------
HEADLESS_MODE: bool = True
WINDOW_SIZE: str = "1920,1080"
IMPLICIT_WAIT_SEC: int = 8
PAGELOAD_TIMEOUT_SEC: int = 30
SCRIPT_TIMEOUT_SEC: int = 30

# ---------- Scraping Controls ----------
REQUEST_TIMEOUT: int = 20
MAX_RETRIES: int = 3
RETRY_BACKOFF_BASE_SEC: float = 1.2  # exponential backoff base
RANDOM_SLEEP_RANGE_SEC = (0.6, 1.8)  # human‑like pacing between actions
PAGINATION_PAGES: int = 3            # pages per query per platform (overridden by UI)

# ---------- Anti‑Detection ----------
USER_AGENTS = [
    # Desktop Chrome variants
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 13_5) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.5 Safari/605.1.15",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
]
PROXIES = []  # e.g., ["http://user:pass@host:port", "http://host:port"]

# ---------- Markets / Currency ----------
DEFAULT_CURRENCY = "INR"
CURRENCY_SYMBOLS = {"INR": "₹", "USD": "$"}
DEFAULT_MARKET_DOMAINS = {
    "amazon": "https://www.amazon.in",
    "flipkart": "https://www.flipkart.com",
}

# If you want FX conversion when scraping USD sites, plug your own callable here.
# It must accept (price: float, from_ccy: str, to_ccy: str) -> float
FOREX_CONVERTER = None  # set at runtime if needed

# ---------- Output / Persistence ----------
SAVE_CSV: bool = True
SAVE_JSON: bool = True
SAVE_SQLITE: bool = False  # optional; enables SQLite persistence
SQLITE_PATH = DATA_DIR / "scrapewise.db"

# ---------- Schema ----------
STANDARD_COLUMNS = [
    "Scrape_Timestamp",
    "Query",
    "Platform",
    "Product",
    "Product_URL",
    "Image_URL",
    "Competitor_Price",
    "Currency",
    "Rating",
    "Reviews",
    "Availability",
    "Seller",
    "Additional",
]
