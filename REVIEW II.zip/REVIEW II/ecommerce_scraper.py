
import time
import logging
import random
import os
from datetime import datetime, UTC
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.chrome.options import Options
from selenium.common.exceptions import TimeoutException
import pandas as pd

# === Configurable Options ===
HEADLESS_MODE = False  # set to True if you want headless
MAX_WAIT = 10

USER_AGENTS = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/115.0 Safari/537.36",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
    "AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.0 Safari/605.1.15",
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/114.0 Safari/537.36"
]

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s"
)

class EcommerceScraper:
    def __init__(self):
        self.driver = None
        self.results = []

    def scrape(self, query, platforms=("amazon", "flipkart"), pages=1, max_products_per_page=None):
        """High-level API used by the Streamlit app. Returns a DataFrame.

        Parameters
        - query: search keywords
        - platforms: iterable of platforms, any of {"amazon","flipkart"}
        - pages: number of listing pages per platform
        - max_products_per_page: optional cap per page per platform
        """
        self.results = []
        plat_list = [p.lower() for p in platforms]
        if "amazon" in plat_list:
            self.scrape_amazon(query, pages=pages, max_products_per_page=max_products_per_page)
        if "flipkart" in plat_list:
            self.scrape_flipkart(query, pages=pages, max_products_per_page=max_products_per_page)
        return self.to_dataframe()

    def close(self):
        self._teardown_driver()

    def _setup_driver(self):
        options = Options()
        if HEADLESS_MODE:
            options.add_argument("--headless=new")
        options.add_argument(f"user-agent={random.choice(USER_AGENTS)}")
        options.add_argument("--disable-blink-features=AutomationControlled")
        self.driver = webdriver.Chrome(options=options)

    def _teardown_driver(self):
        if self.driver:
            self.driver.quit()

    def scrape_amazon(self, query, pages=1, max_products_per_page=None):
        logging.info(f"Scraping Amazon.in | query='{query}' | pages={pages}")
        self._setup_driver()
        base_url = "https://www.amazon.in/s?k=" + query.replace(" ", "+")
        for page in range(1, pages + 1):
            url = f"{base_url}&page={page}"
            self.driver.get(url)
            time.sleep(random.uniform(2, 4))

            # detect block page
            if "rush hour" in self.driver.page_source or "captcha" in self.driver.page_source.lower():
                logging.warning("Amazon served a block page. Saving debug HTML.")
                with open("debug_amazon_block.html", "w", encoding="utf-8") as f:
                    f.write(self.driver.page_source)
                continue

            try:
                products = WebDriverWait(self.driver, MAX_WAIT).until(
                    EC.presence_of_all_elements_located((By.CSS_SELECTOR, '[data-component-type="s-search-result"]'))
                )
            except Exception as e:
                logging.error(f"Amazon timeout/no products found: {e}")
                try:
                    with open("debug_amazon_empty.html", "w", encoding="utf-8") as f:
                        f.write(self.driver.page_source)
                except Exception:
                    pass
                continue

            collected = 0
            for prod in products:
                try:
                    title, link = None, None
                    title_link_candidates = [
                        "h2 a.a-link-normal",
                        "h2 a.a-link-normal.a-text-normal",
                        "a.a-link-normal.s-no-outline"
                    ]
                    for sel in title_link_candidates:
                        t = prod.find_elements(By.CSS_SELECTOR, sel)
                        if t:
                            title = t[0].text.strip()
                            link = t[0].get_attribute("href")
                            break
                    price = None
                    for sel in [
                        "span.a-price span.a-offscreen",
                        "span.a-price-whole",
                        "span.a-offscreen"
                    ]:
                        els = prod.find_elements(By.CSS_SELECTOR, sel)
                        if els:
                            price = els[0].text.strip()
                            break
                    rating = None
                    rating_el = prod.find_elements(By.CSS_SELECTOR, "span.a-icon-alt, span[aria-label$='out of 5 stars']")
                    if rating_el:
                        rating = rating_el[0].get_attribute("innerText").split()[0]
                    reviews = None
                    review_el = prod.find_elements(By.CSS_SELECTOR, "span[aria-label$='ratings'], span[aria-label$='rating']")
                    if review_el:
                        reviews = review_el[0].get_attribute("aria-label")
                    img = None
                    for sel in ["img.s-image", "img"]:
                        img_el = prod.find_elements(By.CSS_SELECTOR, sel)
                        if img_el:
                            img = img_el[0].get_attribute("src")
                            break

                    self.results.append({
                        "Scrape_Timestamp": datetime.now(UTC).isoformat(),
                        "Query": query,
                        "Platform": "Amazon",
                        "Product": title,
                        "Product_URL": link,
                        "Image_URL": img,
                        "Competitor_Price": price,
                        "Currency": "INR",
                        "Rating": rating,
                        "Reviews": reviews,
                        "Availability": "In Stock" if price else "Unavailable",
                        "Seller": None,
                        "Additional": None
                    })
                    collected += 1
                    if max_products_per_page and collected >= max_products_per_page:
                        break
                except Exception:
                    continue

        self._teardown_driver()

    def scrape_flipkart(self, query, pages=1, max_products_per_page=None):
        logging.info(f"Scraping Flipkart | query='{query}' | pages={pages}")
        self._setup_driver()
        base_url = "https://www.flipkart.com/search?q=" + query.replace(" ", "+")
        for page in range(1, pages + 1):
            url = f"{base_url}&page={page}"
            self.driver.get(url)
            time.sleep(random.uniform(2, 4))
            # Try dismissing potential overlays (login/cookie)
            try:
                # Close login modal '✕'
                close_btns = self.driver.find_elements(By.CSS_SELECTOR, "button._2KpZ6l._2doB4z, button._2KpZ6l._2doB4z._3AWRsL")
                if close_btns:
                    close_btns[0].click()
                    time.sleep(0.5)
            except Exception:
                pass
            try:
                consent_btns = self.driver.find_elements(By.XPATH, "//button[contains(., 'Accept') or contains(., 'accept') or contains(., 'OK')]")
                if consent_btns:
                    consent_btns[0].click()
                    time.sleep(0.5)
            except Exception:
                pass
            # Scroll once to trigger lazy loading
            try:
                self.driver.execute_script("window.scrollTo(0, document.body.scrollHeight/2);")
                time.sleep(1.0)
            except Exception:
                pass

            # Try multiple layouts/selectors
            products = []
            try:
                products = WebDriverWait(self.driver, max(MAX_WAIT, 15)).until(
                    EC.presence_of_all_elements_located((By.CSS_SELECTOR, "div._2kHMtA"))
                )
            except Exception:
                pass
            if not products:
                try:
                    products = WebDriverWait(self.driver, max(MAX_WAIT, 15)).until(
                        EC.presence_of_all_elements_located((By.CSS_SELECTOR, "div._13oc-S > div > div"))
                    )
                except Exception:
                    pass
            if not products:
                try:
                    products = WebDriverWait(self.driver, max(MAX_WAIT, 15)).until(
                        EC.presence_of_all_elements_located((By.CSS_SELECTOR, "a._1fQZEK"))
                    )
                except Exception as e:
                    logging.error(f"Flipkart timeout/no products found: {e}")
                    # Save debug HTML for troubleshooting
                    try:
                        with open("debug_flipkart_empty.html", "w", encoding="utf-8") as f:
                            f.write(self.driver.page_source)
                    except Exception:
                        pass
                    continue

            collected = 0
            for prod in products:
                try:
                    # Normalize node depending on layout: card div or anchor
                    card = prod
                    link = None
                    title = None
                    # Layout 1: card div contains link and title
                    try:
                        link_el = card.find_element(By.CSS_SELECTOR, "a._1fQZEK, a._2UzuFa, a._1fQZEK._2UzuFa")
                        link = link_el.get_attribute("href")
                    except Exception:
                        if card.tag_name.lower() == "a":
                            link = card.get_attribute("href")
                    # Title candidates
                    title_candidates = [
                        "div._4rR01T",   # grid layout
                        "a.IRpwTa",      # small cards
                        "div._2B099V .IRpwTa",
                        "div.KzDlHZ",    # newer class
                    ]
                    for sel in title_candidates:
                        found = card.find_elements(By.CSS_SELECTOR, sel)
                        if found:
                            title = found[0].text.strip()
                            break
                    if not title:
                        # last resort: alt on image
                        img_try = card.find_elements(By.CSS_SELECTOR, "img")
                        if img_try:
                            title = img_try[0].get_attribute("alt")

                    price_el = card.find_elements(By.CSS_SELECTOR, "div._30jeq3._1_WHN1, div._30jeq3")
                    price = price_el[0].text.strip() if price_el else None
                    rating_el = card.find_elements(By.CSS_SELECTOR, "div._3LWZlK")
                    rating = rating_el[0].text.strip() if rating_el else None
                    review_el = card.find_elements(By.CSS_SELECTOR, "span._2_R_DZ")
                    reviews = review_el[0].text if review_el else None
                    img_el = card.find_elements(By.CSS_SELECTOR, "img")
                    img = img_el[0].get_attribute("src") if img_el else None

                    self.results.append({
                        "Scrape_Timestamp": datetime.now(UTC).isoformat(),
                        "Query": query,
                        "Platform": "Flipkart",
                        "Product": title,
                        "Product_URL": link,
                        "Image_URL": img,
                        "Competitor_Price": price,
                        "Currency": "INR",
                        "Rating": rating,
                        "Reviews": reviews,
                        "Availability": "In Stock" if price else "Unavailable",
                        "Seller": None,
                        "Additional": None
                    })
                    collected += 1
                    if max_products_per_page and collected >= max_products_per_page:
                        break
                except Exception:
                    continue

        self._teardown_driver()

    def to_dataframe(self):
        return pd.DataFrame(self.results)

    def save(self, fmt="csv"):
        df = self.to_dataframe()
        if df.empty:
            logging.warning("No results to save.")
            return None
        ts = datetime.now(UTC).strftime("%Y%m%d_%H%M%S")
        filename = f"scrape_results_{ts}.{fmt}"
        if fmt == "csv":
            df.to_csv(filename, index=False, encoding="utf-8")
        elif fmt == "json":
            df.to_json(filename, orient="records", indent=2, force_ascii=False)
        logging.info(f"Saved results -> {filename}")
        return filename

if __name__ == "__main__":
    scraper = EcommerceScraper()
    scraper.scrape_amazon("laptop", pages=1)
    scraper.scrape_flipkart("laptop", pages=1)
    df = scraper.to_dataframe()
    print(df.head())
    scraper.save("csv")
