import streamlit as st
import pandas as pd
import numpy as np
from datetime import datetime
import plotly.graph_objects as go
import plotly.express as px

from ecommerce_scraper import EcommerceScraper
from config import DEFAULT_CURRENCY, CURRENCY_SYMBOLS, STANDARD_COLUMNS

st.set_page_config(page_title="ScrapeWise DSS — Pricing Intelligence", page_icon="🧠", layout="wide")

# ---------- Helpers ----------
def fmt_money(v, ccy=DEFAULT_CURRENCY):
    if v is None or (isinstance(v, float) and np.isnan(v)):
        return "-"
    sym = CURRENCY_SYMBOLS.get(ccy, "")
    return f"{sym}{v:,.0f}"

@st.cache_data(show_spinner=False)
def _dummy_internal_data():
    return pd.DataFrame({
        "Product": ["MacBook Pro 13", "iPhone 15 Pro", "Sony WH-1000XM5", "Samsung Galaxy S24", "AirPods Pro"],
        "Our_Price": [135000, 105000, 37000, 125000, 27000],
        "Cost_Price": [110000, 85000, 28000, 100000, 20000],
        "Stock": [15, 8, 25, 0, 50],
        "Category": ["Laptops", "Smartphones", "Audio", "Smartphones", "Audio"],
    })

def enrich(scraped: pd.DataFrame, internal: pd.DataFrame) -> pd.DataFrame:
    df = scraped.copy()
    # normalize Product matching using case-insensitive containment
    merged = df.merge(internal, how="left",
                      left_on="Product", right_on="Product",
                      suffixes=("", "_our"))
    # heuristics: if no exact match, try fuzzy contains (simple)
    if merged["Our_Price"].isna().all():
        # try basic contains by keywords from internal products
        for _, row in internal.iterrows():
            mask = merged["Product"].str.contains('|'.join(row["Product"].split()), case=False, na=False)
            merged.loc[mask, ["Our_Price","Cost_Price","Stock","Category"]] = row[["Our_Price","Cost_Price","Stock","Category"]].values
    # metrics
    merged["Price_Diff"] = merged["Our_Price"] - merged["Competitor_Price"]
    merged["Current_Margin_%"] = (merged["Our_Price"] - merged["Cost_Price"]) / merged["Our_Price"] * 100
    merged["Potential_Margin_%"] = (merged["Competitor_Price"] - merged["Cost_Price"]) / merged["Competitor_Price"] * 100
    merged["Risk_Level"] = np.where(merged["Stock"].fillna(0) <= 5, "High",
                            np.where(merged["Price_Diff"] > 10000, "Medium", "Low"))
    merged["Opportunity_Score"] = np.where(
        (merged["Competitor_Price"] > 0) & (merged["Stock"].fillna(0) > 0),
        (merged["Competitor_Price"] - merged["Our_Price"]).fillna(0),
        0
    )
    return merged

# ---------- UI ----------
st.markdown("<h1>🧠 ScrapeWise DSS</h1>", unsafe_allow_html=True)
st.caption("Live competitor scraping • INR‑native analytics • What‑if simulator")

with st.sidebar:
    st.header("Scrape Controls")
    query = st.text_input("Search query", value="laptop")
    platforms = st.multiselect("Platforms", ["amazon","flipkart"], default=["amazon","flipkart"])
    pages = st.slider("Pages per platform", 1, 5, 1)
    mpp = st.slider("Max products per page", 5, 24, 12)
    live = st.toggle("Use live scraping", value=True)
    st.divider()
    st.header("What‑If Simulator")
    adj_pct = st.slider("Simulate competitor price change (%)", -40, 40, 0)

colA, colB = st.columns([1,1])

# ---------- Data ----------
internal_df = _dummy_internal_data()
if live:
    with st.spinner("Scraping live competitor data..."):
        scraper = EcommerceScraper()
        try:
            scraped_df = scraper.scrape(query=query, platforms=platforms, pages=pages, max_products_per_page=mpp)
        finally:
            scraper.close()
else:
    scraped_df = pd.DataFrame(columns=STANDARD_COLUMNS)

if scraped_df.empty:
    st.warning("No results found. Try different keywords or increase pages.")
else:
    # show raw scraped
    st.subheader("Competitor Results (Live)")
    st.dataframe(scraped_df, use_container_width=True)

    # what-if: adjust competitor prices
    if adj_pct != 0:
        scraped_df = scraped_df.copy()
        scraped_df["Competitor_Price"] = (scraped_df["Competitor_Price"] * (1 + adj_pct/100)).round(0)

    # enrich and compute
    analysis = enrich(scraped_df, internal_df)

    st.subheader("Pricing Analysis (INR)")
    view = analysis[["Platform","Product","Competitor_Price","Our_Price","Price_Diff","Current_Margin_%","Risk_Level","Opportunity_Score"]].copy()
    # format money
    for col in ["Competitor_Price","Our_Price","Price_Diff"]:
        view[col] = view[col].apply(lambda x: fmt_money(x))
    st.dataframe(view, use_container_width=True)

    # charts
    st.subheader("Visuals")
    fig = go.Figure()
    for plat in analysis["Platform"].unique():
        sub = analysis[analysis["Platform"]==plat]
        fig.add_trace(go.Bar(name=f"{plat} — Competitor", x=sub["Product"], y=sub["Competitor_Price"]))
        fig.add_trace(go.Bar(name=f"{plat} — Our", x=sub["Product"], y=sub["Our_Price"]))
    fig.update_layout(barmode="group", title="Price Comparison (INR)")
    st.plotly_chart(fig, use_container_width=True)

    fig2 = px.scatter(
        analysis, x="Our_Price", y="Current_Margin_%",
        size="Stock", color="Risk_Level", hover_name="Product",
        title="Margin vs Price — Bubble by Stock"
    )
    st.plotly_chart(fig2, use_container_width=True)

st.divider()
st.markdown("**Example Scenario:** Toggle *What‑If Simulator* in the sidebar to model a ±% change in competitor prices and observe impact on your margins and opportunity scores in real‑time.")
