from ecommerce_scraper import EcommerceScraper

if __name__ == "__main__":
    scraper = EcommerceScraper()
    scraper.scrape_amazon("laptop", pages=1, max_products_per_page=10)
    df = scraper.to_dataframe()
    print("ROWS=", len(df))
    if not df.empty:
        print(df.head().to_string())
    else:
        print("No Amazon rows scraped.")


